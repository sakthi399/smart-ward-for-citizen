import React, { useState, useEffect } from 'react'
import Splash from './components/Splash.jsx'
import axios from 'axios'
import { Routes, Route } from 'react-router-dom'
import Home from './components/Home.jsx'
import About from './components/About.jsx'
import Userprofile from './components/Userprofile.jsx'
import ComplaintForm from './components/Complaint.jsx'

import Navbar from './components/Navbar.jsx'

import Login from './components/Login.jsx';
import Signup from './components/Signup.jsx';
import logo from './assets/logo.jpg'


const App = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [users, setUsers] = useState([]);

  const [showSplash, setShowSplash] = useState(true);


  // Fetch users from the backend

  useEffect(() => {
    axios.get('http://localhost:5000/signup')
      .then(res => setUsers(res.data))
      .catch(err => console.error('Error fetching users:', err));
  }, []);


useEffect(() => {
  const timer = setTimeout(() => {
    setShowSplash(false); // hide splash after 2.5s
  }, 2500);

  return () => clearTimeout(timer);
}, []);




  return (
    <div className="flex min-h-screen bg-gray-100">
      <Navbar open={sidebarOpen} setOpen={setSidebarOpen} />
      <main
        className={`flex-1 transition-all duration-300 p-4 md:p-6 ${sidebarOpen ? 'md:ml-64' : 'ml-0'
          }`}
      >
        {/* Header Row */}
        <div className="mb-8 w-full flex items-center justify-center relative pl-24">
          {/* Logo shifted right */}
          <h1 className="flex-2  text-3xl md:text-5xl font-bold font-sans text-black tracking-wide uppercase ml-[-100px] ">Smart Ward</h1>
          <img
            src={logo}
            alt="Smart Ward Logo"
            className="w-16 h-16 object-contain rounded-full shadow mr-4  ml-[18px]"
          />
          {/* Centered Heading 
          <h1 className="flex-2  text-3xl md:text-5xl font-bold font-sans text-black tracking-wide uppercase  ml-[-490px]">
            Smart Ward
          </h1>*/}
        </div>
        {/* Underline */}
        <div className="mx-auto mb-8 w-2/2 h-1 bg-black rounded"></div>
        {showSplash ? (
          <Splash />
        ) : (

          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/userprofile" element={<Userprofile />} />
            <Route path="/complaint" element={<ComplaintForm />} />
          </Routes>
        )}
      </main>
    </div>
  )
}

export default App