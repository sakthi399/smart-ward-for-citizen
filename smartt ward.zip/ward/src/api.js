import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000", // your Express server
  withCredentials: true,
});

// ---------- AUTH ----------
export const signup = (data) => API.post("/signup", data);
export const login = (data) => API.post("/login", data);
export const getUsers = () => API.get("/users");

// ---------- FEEDBACK ----------
export const sendFeedback = (data) => API.post("/feedback", data);
export const getFeedbacks = () => API.get("/feedback");

// ---------- USER PROFILES ----------
export const createProfile = (formData) =>
  API.post("/profiles/create", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
export const getProfiles = () => API.get("/profiles");

// ---------- COMPLAINTS ----------
export const submitComplaint = (formData) =>
  API.post("/complaints/submit", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
export const getComplaints = () => API.get("/complaints");
