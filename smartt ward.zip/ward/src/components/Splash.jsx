// Splash.jsx
import { motion } from "framer-motion";
import React, { useEffect, useState } from "react";



const Splash = ({ onFinish }) => {
  useEffect(() => {
    // Auto-hide after 2.5 seconds
    const timer = setTimeout(() => {
      onFinish();
    }, 6000);

    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-blue-500 z-50">
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 2.5 }} // grow and fade in
      >
        <h1 className="text-5xl font-bold text-white">Smart Ward</h1>
      </motion.div>
      <motion.div
        className="absolute bottom-20 w-32 h-1 bg-blue-500 rounded"
        initial={{ width: 0 }}
        animate={{ width: "100%" }}
        transition={{ duration: 6 }} // progress bar fills in 5s
      />
    </div>
  );
};

export default Splash;
