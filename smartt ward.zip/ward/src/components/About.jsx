import React from 'react'

const About = () => {
  return (
    <>
      <div className="min-h-screen flex flex-col items-center justify-center px-4 space-y-6 transform translate-y-[30px]">
        <h1 className="text-center text-2xl md:text-3xl font-bold font-sans bg-black text-white px-7 py-5 rounded-3xl">
          About Smart Ward
        </h1>

        <div className="w-full max-w-6xl mx-auto mt-10">
          {/* Outer big box with scroll behavior */}
          <div className="transform translate-y-[-1px] w-full h-[770px] overflow-y-auto rounded-lg border-2 border-gray-300 p-8 shadow-md bg-white">

            {/* Message box */}
            <div className="p-9 bg-gradient-to-r from-indigo-400 to-cyan-400 border-blue-500 rounded-md animate-slide-in h-auto">
              <h3 className="font-bold text-3xl bg-gradient-to-r from-black to-transparent text-white px-11 py-4 rounded-xl text-center mb-6">
                Project Purpose
              </h3>

              <div className="space-y-6 text-white text-lg leading-relaxed tracking-wide px-6">
                <p>
                  The <strong>Smart Ward Application</strong> is an innovative digital platform developed to simplify and modernize 
                  the process of lodging civic complaints and improving communication between citizens and municipal authorities. 
                  It allows residents of a specific ward to easily report local issues such as garbage mismanagement, water logging, 
                  drainage problems, and other public grievances directly from their mobile devices.
                </p>

                <p>
                  Instead of following manual complaint procedures, citizens can submit complaints online, ensuring 
                  <strong> faster responses, transparency,</strong> and <strong>accountability</strong> in local governance. 
                  The system connects <strong>citizens, councilors, mayors,</strong> and <strong>municipal commissioners</strong> 
                  in a single digital platform, making communication more efficient.
                </p>

                <p>
                  Each complaint is automatically directed to the appropriate authority based on the user’s ward and complaint type. 
                  The system also generates a downloadable <strong>Proof PDF</strong> for users to keep as evidence for future escalations 
                  or follow-ups.
                </p>

                <h4 className="font-semibold text-2xl mt-10 mb-4 underline underline-offset-4">Key Features</h4>
                <ul className="list-disc list-inside space-y-2">
                  <li>Online complaint submission and tracking.</li>
                  <li>Automatic proof PDF generation for user reference.</li>
                  <li>Role-based access for users, councilors, mayor, commissioner, and admin.</li>
                  <li>Ward meeting details and community announcements.</li>
                  <li>Citizen feedback system for improvement.</li>
                  <li>Admin tools for managing users and complaints efficiently.</li>
                </ul>

                <h4 className="font-semibold text-2xl mt-10 mb-4 underline underline-offset-4">Technologies Used</h4>
                <ul className="list-disc list-inside space-y-2">
                  <li><strong>Frontend:</strong> React.js with Tailwind CSS for responsive UI.</li>
                  <li><strong>Backend:</strong> Node.js and Express.js for server-side operations.</li>
                  <li><strong>Database:</strong> MongoDB Compass for storing and managing data.</li>
                </ul>

                <h4 className="font-semibold text-2xl mt-10 mb-4 underline underline-offset-4">Purpose</h4>
                <p>
                  The main goal of the Smart Ward Application is to <strong>empower citizens</strong> by making it simple to report 
                  civic issues and enhance coordination among local government bodies. 
                  It ensures transparency, accountability, and efficiency in addressing community problems, 
                  ultimately improving the quality of urban services and civic life.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default About
