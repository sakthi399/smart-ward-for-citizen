import React, { useState, useEffect } from "react";
import axios from "axios";

const Userprofile = () => {
  const [formData, setFormData] = useState({
    fullName: "",
    wardNo: "",
    houseNo: "",
    street: "",
    city: "",
    dob: "",
    gender: "",
    mobile: "",
    email: "",
    image: null,        // profile picture
    voterIdImage: null, // voter ID photo
  });

  const [preview, setPreview] = useState(null);
  const [voterPreview, setVoterPreview] = useState(null);

  // Load existing profile if any
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get("http://localhost:5000/profiles/me", {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });

        if (res.data) {
          setFormData({ ...formData, ...res.data });
          if (res.data.image) setPreview(`http://localhost:5000${res.data.image}`);
          if (res.data.voterIdImage) setVoterPreview(`http://localhost:5000${res.data.voterIdImage}`);
        }
      } catch (err) {
        console.log("No existing profile found, creating new profile.");
      }
    };
    fetchProfile();
  }, []);

  // Handle text input
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle profile image
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setPreview(URL.createObjectURL(file));
    }
  };

  // Handle voter ID image
  const handleVoterImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, voterIdImage: file });
      setVoterPreview(URL.createObjectURL(file));
    }
  };

  // Submit form
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const data = new FormData();

      // append text fields
      ["fullName", "wardNo", "houseNo", "street", "city", "dob", "gender", "mobile", "email"].forEach((key) => {
        data.append(key, formData[key]);
      });

      // append images
      if (formData.image) data.append("image", formData.image);
      if (formData.voterIdImage) data.append("voterIdImage", formData.voterIdImage);

      // Check if profile exists
      let profileExists = false;
      try {
        const existing = await axios.get("http://localhost:5000/profiles/me", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (existing.data) profileExists = true;
    } catch (err) {
      // No profile exists → continue to create
      profileExists = false;
    }

    const res = profileExists
      ? await axios.put("http://localhost:5000/profiles/update", data, {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        })
      : await axios.post("http://localhost:5000/profiles/create", data, {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });

    alert(profileExists ? "✅ Profile Updated Successfully!" : "✅ Profile Created Successfully!");
  } catch (err) {
    console.error("Error saving profile:", err);
    alert("❌ Error: " + (err.response?.data?.error || "Something went wrong"));
  }
};

    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 to-teal-400 p-10">
        <form
          onSubmit={handleSubmit}
          className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-2xl space-y-6"
        >
          <h2 className="text-2xl font-bold text-center text-blue-600">
            Smart Ward - User Profile Creation
          </h2>

          {/* Profile Image */}
          <div className="flex flex-col items-center">
            {preview ? (
              <img src={preview} alt="Profile Preview" className="w-24 h-24 rounded-full object-cover mb-3 shadow-md" />
            ) : (
              <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center mb-3">
                <span className="text-gray-600 text-sm">No image</span>
              </div>
            )}
            <p className="mb-4 ">only support <b>JPEG, PNG,PDF </b>images</p>
            <label className="cursor-pointer bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition">
              Upload Profile Image

              <input type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
            </label>
          </div>

          {/* Full Name */}
          <div>
            <label className="block text-gray-700 font-medium">Full Name</label>
            <input type="text" name="fullName" value={formData.fullName} onChange={handleChange}
              className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" required />
          </div>

          {/* Ward Number */}
          <div>
            <label className="block text-gray-700 font-medium">Ward No</label>
            <input type="number" name="wardNo" value={formData.wardNo} onChange={handleChange}
              className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" required />
          </div>

          {/* Address */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-gray-700 font-medium">House No</label>
              <input type="text" name="houseNo" value={formData.houseNo} onChange={handleChange}
                className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" />
            </div>
            <div>
              <label className="block text-gray-700 font-medium">Street Name</label>
              <input type="text" name="street" value={formData.street} onChange={handleChange}
                className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" />
            </div>
            <div>
              <label className="block text-gray-700 font-medium">City / Town / Village</label>
              <input type="text" name="city" value={formData.city} onChange={handleChange}
                className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" />
            </div>
          </div>

          {/* Date of Birth */}
          <div>
            <label className="block text-gray-700 font-medium">Date of Birth</label>
            <input type="date" name="dob" value={formData.dob} onChange={handleChange}
              className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" required />
          </div>

          {/* Gender */}
          <div>
            <label className="block text-gray-700 font-medium">Gender</label>
            <select name="gender" value={formData.gender} onChange={handleChange}
              className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" required>
              <option value="">-- Select Gender --</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>

          {/* Mobile */}
          <div>
            <label className="block text-gray-700 font-medium">Mobile No</label>
            <input type="tel" name="mobile" value={formData.mobile} onChange={handleChange}
              className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" required />
          </div>

          {/* Email */}
          <div>
            <label className="block text-gray-700 font-medium">Email Address</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange}
              className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" required />
          </div>

          {/* Voter ID Image */}
          <div>
            <label className="block text-gray-700 font-medium">Upload Voter ID Profile only Support <b>JPEG , PNG , PDF </b>images</label>
            {voterPreview && (
              <img src={voterPreview} alt="Voter ID Preview" className="w-40 h-28 object-cover mb-3 shadow-md rounded-md" />
            )}
            <input type="file" accept="image/*" onChange={handleVoterImageChange}
              className="w-full mt-1 p-2 border rounded-lg focus:ring focus:ring-blue-300" required />
          </div>

          {/* Submit */}
          <button type="submit"
            className="w-full font-bold text-lg bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">
            Create Profile
          </button>
        </form>
      </div>
    );
  };

  export default Userprofile;
