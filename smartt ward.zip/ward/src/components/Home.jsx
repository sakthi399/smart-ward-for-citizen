import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

import envi from '../assets/envi.jpg';
import health from '../assets/health.png';
import savewater from '../assets/savewater.webp';
import solor from '../assets/solor.jpg';
import waste from '../assets/waste.jpg';

const cards = [
  { title: 'Save Our Environment', image: envi, description: 'We keep our environment clean and green.' },
  { title: 'Health and Wellness', image: health, description: 'Monitor your regular health by checkups and improve by consuming good diet and physical activities.' },
  { title: 'Save Water', image: savewater, description: 'Sustainable Development of Water for Future Generations.' },
  { title: 'Use Solar as Renewable Energy', image: solor, description: 'Use Solar Energy to Reduce Carbon Footprint and Save Electricity Bills.' },
  { title: 'Dispose of Waste Properly', image: waste, description: 'Proper Waste Disposal for a Cleaner and Healthier Environment.' },
];

const Home = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [feedback, setFeedback] = useState("");
  const [user, setUser] = useState(null);
  const [current, setCurrent] = useState(0);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showPasswordBox, setShowPasswordBox] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;

    const fetchUserProfile = async () => {
      try {
        const res = await axios.get("http://localhost:5000/users/me", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(res.data);
        setEmail(res.data.email);
      } catch {
        navigate("/home");
      }
    };
    fetchUserProfile();
  }, [navigate]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % cards.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");
    try {
      await axios.post(
        "http://localhost:5000/feedbacks",
        { email, feedback },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert("✅ Feedback submitted successfully!");
      setFeedback("");
    } catch {
      alert("❌ Failed to submit feedback");
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");
    try {
      await axios.put(
        "http://localhost:5000/users/change-password",
        { oldPassword, newPassword },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert("✅ Password changed successfully!");
      setOldPassword("");
      setNewPassword("");
      setShowPasswordBox(false);
    } catch {
      alert("❌ Failed to change password");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6 space-y-10">
      {/* ----------- USER PROFILE BOX ----------- */}
      {user && (
        <div className="max-w-sm ml-auto bg-blue-500 text-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">User Profile</h2>
            <button
              onClick={() => {
                localStorage.removeItem("token");
                setUser(null);
                navigate("/login");
              }}
              className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded"
            >
              🔓 Logout
            </button>
          </div>
          <div className="w-20 h-20 rounded-full my-4 border-2 border-white overflow-hidden flex items-center justify-center bg-gray-200">
            {user.image ? (
              <img src={`http://localhost:5000${user.image}`} alt="user" className="w-full h-full object-cover" />
            ) : (
              <span className="text-gray-700 font-bold text-2xl">
                {user.fullName ? user.fullName.charAt(0).toUpperCase() : "U"}
              </span>
            )}
          </div>
          <p><b>Name:</b> {user.fullName}</p>
          <p><b>User ID:</b> {user._id}</p>
          <p><b>Email:</b> {user.email}</p>
          <p><b>Mobile:</b> {user.mobile || "-"}</p>
          <p><b>Ward No:</b> {user.wardNo || "-"}</p>

          <button
            onClick={() => setShowPasswordBox(!showPasswordBox)}
            className="mt-4 bg-green-500 hover:bg-green-700 text-white px-3 py-1 rounded"
          >
            {showPasswordBox ? "Close Change Password" : "Change Password"}
          </button>
          <button
            onClick={() => navigate("/userprofile")}
            className="mt-4 bg-yellow-500 hover:bg-yellow-600 text-white px-5 py-1 rounded w-full"
          >
            Update Profile
          </button>

          {showPasswordBox && (
            <form className="mt-4 bg-white text-black rounded-lg p-4" onSubmit={handleChangePassword}>
              <input
                type="password"
                placeholder="Old Password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                className="w-full p-2 mb-2 rounded border"
                required
              />
              <input
                type="password"
                placeholder="New Password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full p-2 mb-2 rounded border"
                required
              />
              <button className="w-full bg-green-500 text-white py-2 rounded hover:bg-green-700">Update Password</button>
            </form>
          )}
        </div>
      )}

      {/* ----------- CAROUSEL ----------- */}
      <div className="flex flex-col  items-center">
        <h2 className="text-2xl mt-[-30px] ml-[-200px] font-semibold bg-gradient-to-r from-black to-transparent text-white px-6 py-3 rounded-xl mb-4">
          Sustainable India
        </h2>
        <div className="w-full max-w-2xl bg-white rounded-xl shadow-xl p-6 flex flex-col ml-[-200px] items-center">
          <img src={cards[current].image} alt={cards[current].title} className="w-full h-[400px] object-cover rounded-md mb-3" />
          <h3 className="text-lg font-semibold">{cards[current].title}</h3>
          <p className="text-gray-600">{cards[current].description}</p>
          <div className="flex justify-center mt-4 space-x-2">
            {cards.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrent(idx)}
                className={`w-3 h-3 rounded-full ${current === idx ? "bg-blue-600" : "bg-gray-300"}`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* ----------- WARD PROGRAMS ----------- */}
      <section className="max-w-5xl mx-auto space-y-10">
        <h1 className="text-3xl font-semibold bg-gradient-to-r from-black to-transparent text-white px-6 py-3 rounded-xl text-center">
          # Ward Program Schedules
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Ward Boxes */}
          {[
            { ward: 1, desc: "Community meeting this Saturday at 10 AM.", campaign: "Public parks improvement by Mrs. Arun" },
            { ward: 2, desc: "Meeting postponed due to rain.", campaign: "Welfare scheme for poor by M. BalaMurugan" },
            { ward: 3, desc: "Still not updated.", campaign: "Cycle campaign for pollution awareness by M. Rajesh" },
            { ward: 4, desc: "Meeting this Sunday at 11 AM.", campaign: "Campaign soon by J. Mahesh" },
            { ward: 5, desc: "Still not updated.", campaign: "Dengue awareness campaign by L. Suriya" },
          ].map((w, i) => (
            <div key={i} className="bg-blue-500 p-4 border rounded-lg shadow-md">
              <h3 className="font-bold  text-white mb-2">Ward {w.ward} Sabha</h3>
              <p className="text-sm text-white">{w.desc}</p>
              <div className="mt-3 bg-green-200 border p-2 rounded-md">
                <h4 className="font-bold text-green-700">Councilor's Campaign</h4>
                <p className="text-sm text-gray-700">{w.campaign}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ----------- CITIZEN RESPONSIBILITIES ----------- */}
      <section className="max-w-4xl mx-auto bg-gradient-to-r from-blue-400 to-lime-200 p-8 rounded-xl shadow-lg">
        <h3 className="text-3xl font-bold text-center bg-gradient-to-r from-stone-800 to-transparent text-white px-11 py-4 rounded-xl mb-4">
          Citizen's Responsibilities #
        </h3>
        <p className="text-lg text-gray-900 leading-relaxed space-y-3">
          <b>* Attend ward meetings and forums to voice concerns and suggest improvements.</b><br />
          <b>* Report sanitation or water issues promptly to ward officials.</b><br />
          <b>* Participate in health camps, cleanliness drives, and awareness campaigns.</b><br />
          <b>* Vote responsibly for councillors representing your ward.</b><br />
          <b>* Notify local authorities about potholes or garbage collection delays.</b><br />
          <b>* Follow public cleanliness and construction regulations.</b><br />
          <b>* Request updates on local development projects and budgets.</b><br />
          <b>* Encourage civic participation in your neighborhood.</b><br />
          <b>* Support ward committees working for community welfare.</b>
        </p>
      </section>

      {/* ----------- FEEDBACK SECTION ----------- */}
      <section className="max-w-md mx-auto">
        <h1 className="text-3xl font-semibold bg-gradient-to-r from-black to-transparent text-white px-6 py-3 rounded-xl text-center mb-4">
          # Share Your Feedback About SmartWard
        </h1>
        <div className="border-4 border-blue-600 rounded-lg shadow-lg p-6 bg-white">
          {user ? (
            <form className="space-y-4" onSubmit={handleSubmit}>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border rounded-md"
                placeholder="Email"
                required
              />
              <textarea
                rows="4"
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                className="w-full px-4 py-2 border rounded-md"
                placeholder="Share your feedback..."
              />
              <button className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">
                Submit
              </button>
            </form>
          ) : (
            <div className="text-center text-red-700 font-semibold">
              ⚠️ Please login to submit feedback.
            </div>
          )}
        </div>
      </section>

      {/* ----------- FOOTER ----------- */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-6xl mx-auto px-6">
          <h1 className="text-2xl font-semibold bg-gradient-to-r from-black to-transparent text-white px-6 py-3 rounded-xl mb-4">
            # Citizens' Useful Schemes
          </h1>
          <div className="space-y-2">
            <a href="https://abdm.gov.in/" className="hover:text-blue-400">* Ayushman Scheme</a><br />
            <a href="https://www.india.gov.in/spotlight/rashtriya-vayoshri-yojana" className="hover:text-blue-400">* Rashtriya Vayoshri Yojana (Senior Citizens)</a><br />
            <a href="https://pmkisan.gov.in/" className="hover:text-blue-400">* PM Kisan Samman Nidhi Yojana</a><br />
            <a href="https://nrega.dord.gov.in/" className="hover:text-blue-400">* MGNREGA</a><br />
            <a href="https://www.mudra.org.in/" className="hover:text-blue-400">* MUDRA YOJANA</a><br />
            <a href="https://eshram.gov.in/" className="hover:text-blue-400">* E-Shram Portal</a><br />
            <a href="https://www.india.gov.in/spotlight/national-pension-system-retirement-plan-all" className="hover:text-blue-400">* National Pension System</a><br />
            <a href="https://pmvishwakarma.gov.in/" className="hover:text-blue-400">* PM Vishwakarma Scheme</a>
          </div>
          <p className="text-sm mt-6 text-center">&copy; {new Date().getFullYear()} My SmartWard App</p>
        </div>
      </footer>
    </div>
  );
};

export default Home;
