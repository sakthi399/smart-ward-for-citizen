import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const Navbar = ({ open, setOpen }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <>
      <button
        className="fixed top-8 left-4 z-50 bg-blue-600 text-white px-4 py-2 rounded focus:outline-none"
        onClick={() => setOpen(!open)}
      >
        {open ? 'Close Menu' : 'Open Menu'}
      </button>
      <nav
        className={`fixed top-0 left-0 h-full bg-gray-800 text-white w-64 pt-20 transform ${
          open ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 z-40`}
      >
        <ul className="flex flex-col space-y-4 text-lg font-semibold">
          {/* Login and Sign Up at the top */}
          <li>
            <NavLink
              to="/login"
              className="hover:bg-green-600 hover:text-white px-4 py-2 rounded block transition-colors duration-200 font-bold"
              onClick={() => setOpen(false)}
            >
              Login
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/signup"
              className="hover:bg-green-600 hover:text-white px-4 py-2 rounded block transition-colors duration-200 font-bold"
              onClick={() => setOpen(false)}
            >
              Sign Up
            </NavLink>
          </li>
          {/* Other menu items */}
          <li>
            <NavLink
              to="/home"
              className="hover:bg-blue-600 hover:text-white px-4 py-2 rounded block transition-colors duration-200 font-bold"
              onClick={() => setOpen(false)}
            >
              Home
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/about"
              className="hover:bg-blue-600 hover:text-white px-4 py-2 rounded block transition-colors duration-200 font-bold"
              onClick={() => setOpen(false)}
            >
              About
            </NavLink>

          
          </li>

          <li>
            <NavLink
              to="/userprofile"
              className="hover:bg-blue-600 hover:text-white px-4 py-2 rounded block transition-colors duration-200 font-bold"
              onClick={() => setOpen(false)}
            >
              UserProfile
            </NavLink>
            
          
          </li>

          <li>
            <NavLink
              to="/complaint"
              className="hover:bg-blue-600 hover:text-white px-4 py-2 rounded block transition-colors duration-200 font-bold"
              onClick={() => setOpen(false)}
            >
              ComplaintBox
            </NavLink>
            
          
          </li>

          <li className="relative"
              onMouseEnter={() => setDropdownOpen(true)}
              onMouseLeave={() => setDropdownOpen(false)}
          >
            
          </li>
        </ul>
      </nav>
    </>
  );
};

export default Navbar;