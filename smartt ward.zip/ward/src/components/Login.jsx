import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState(""); // To know if user is Councilor
  const [wardNo, setWardNo] = useState(""); // Only for Councilor
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const payload = { email, password };
      if (role === "Councilor" && wardNo) {
        payload.wardNo = Number(wardNo); // only include wardNo if Councilor
      }

      const res = await axios.post("http://localhost:5000/login", payload);

      if (res.data.token) {
        localStorage.setItem("token", res.data.token);
        localStorage.setItem("role", res.data.user.role);
        localStorage.setItem("userId", res.data.user._id);
      }

      toast.success("✅ Login successful!");

      // Redirect based on role
      switch (res.data.user.role) {
        case "Mayor":
          navigate("/mayor-dashboard");
          break;
        case "Councilor":
          navigate("/councilor-dashboard");
          break;
        case "Commissioner":
          navigate("/commissioner-dashboard");
          break;
        default:
          navigate("/home");
      }
    } catch (err) {
      console.error("❌ Login error:", err);
      alert(err.response?.data?.message || "Invalid Email or Password ❌");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 to-teal-500">
      <div className="max-w-sm mx-auto mt-12 bg-white p-8 rounded-2xl shadow border-4 border-blue-500">
        <h2 className="text-2xl font-bold mb-6 text-center">Login To Smart Ward</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email input */}
          <input
            type="email"
            className="w-full border px-3 py-2 rounded"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          {/* Password input */}
          <input
            type="password"
            className="w-full border px-3 py-2 rounded"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded font-semibold hover:bg-blue-700 transition"
          >
            Login
          </button>
        </form>

        <div className="text-center mt-4">
          <a href="/signup" className="text-blue-600 hover:underline">
            Don't have an account? Sign Up
          </a>
        </div>
      </div>
    </div>
  );
};

export default Login;
