import React, { useState } from 'react';
import axios from 'axios';






const Signup = () => {
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [generatedPassword, setGeneratedPassword] = useState('');
  const [errors, setErrors] = useState({});

  // Function to generate a random password
  const generatePassword = (length = 8) => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$!';
    let pass = '';
    for (let i = 0; i < length; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return pass;
  };

  const validateForm = () => {
    let formErrors = {};
    let isValid = true;

    // Email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      formErrors.email = 'Email is required';
      isValid = false;
    } else if (!emailPattern.test(email)) {
      formErrors.email = 'Enter a valid email address';
      isValid = false;
    }

    // Mobile number validation
    const mobilePattern = /^[0-9]{10}$/; // 10 digit number
    if (!mobile) {
      formErrors.mobile = 'Mobile number is required';
      isValid = false;
    } else if (!mobilePattern.test(mobile)) {
      formErrors.mobile = 'Enter a valid 10-digit mobile number';
      isValid = false;
    }

    setErrors(formErrors);
    return isValid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // 👈 stop full page reload

    if (!validateForm()) return; // Validate form before proceeding

    const newpassword = generatePassword();
    setGeneratedPassword(newpassword);

    try {
      const res = await axios.post('http://localhost:5000/signup', {
        email,
        mobile_no: mobile,
        password: newpassword
      });
      alert(res.data.message);
    } catch (err) {
      if (err.response) {
        console.error("Backend error:", err.response.data);
      } else {
        console.error("Network/Other error:", err.message);
      }
      alert('Signup failed❌');
    }

  };


  return (
    <div className="min-h-screen flex  items-center justify-center bg-gradient-to-br from-indigo-600 to-teal-400">

      <div className="  max-w-sm  w-[500px] h-[440px] mx-auto mt-12 bg-white p-8 rounded-2xl shadow w-400 border-4 border-blue-300">
        <h2 className="text-2xl font-bold mb-6 text-center">Sign Up To Smart ward</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="email"
              className="w-full border px-3 py-2 rounded"
              placeholder="Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
            {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}
          </div>

          <div>
            <input
              type="tel"
              className="w-full border px-3 py-2 rounded"
              placeholder="Mobile Number"
              value={mobile}
              onChange={e => setMobile(e.target.value)}
            />
            {errors.mobile && <p className="text-red-500 text-sm">{errors.mobile}</p>}
          </div>

          <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded font-semibold">
            Sign Up
          </button>
        </form>

        {generatedPassword && (
          <div className="mt-4 p-4 border rounded-xl bg-gray-100 text-center">
            <p className="font-semibold">🎉 Your account has been created!</p>
            <p className="text-red-600 font-mono mt-2">
              Password: {generatedPassword}
            </p>
            <button
              onClick={() => navigator.clipboard.writeText(generatedPassword)}
              className="mt-2 px-4 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Copy Password
            </button>
            <p className="text-sm text-gray-600 mt-2">
              ⚠️ <b>Please save this password carefully. You will need it to log in. If you lose it, you will have to create a new account.</b>
            </p>
          </div>
        )}

        <div className="text-center mt-4">
          <a href="/login" className="text-blue-600 hover:underline">
            Already have an account? Login
          </a>
        </div>


      </div>
    </div>

  );
};

export default Signup;
