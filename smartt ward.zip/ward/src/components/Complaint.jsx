import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";


const Complaint = () => {
  const navigate = useNavigate();
  const [complaint, setComplaint] = useState("");
  const [recipient, setRecipient] = useState("");
  const [wardNo, setWardNo] = useState("");
  const [pdfFile, setPdfFile] = useState(null);
  const [message, setMessage] = useState("");

  const [userProfile, setUserProfile] = useState(null); // new state to store user profile
  const [proofPdf, setProofPdf] = useState(null);
  // Fetch logged-in user profile on component mount
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const res = await axios.get("http://localhost:5000/profiles/me", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setUserProfile(res.data); // store the profile
      } catch (err) {
        console.error("Failed to fetch profile:", err.response?.data || err.message);
      }
    };

    fetchUserProfile();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!recipient) return setMessage("⚠️ Please select who to send your complaint to!");
    if (recipient === "Councilor" && !wardNo) return setMessage("⚠️ Please select a ward number for Councilor!");
    if ((recipient === "Mayor" || recipient === "Commissioner") && pdfFile && pdfFile.type !== "application/pdf") {
      return setMessage("⚠️ Only PDF files are allowed!");
    }

    try {
      const data = new FormData();
      data.append("recipientType", recipient);
      data.append("complaint", complaint);
      if (pdfFile) data.append("pdfFile", pdfFile);
      if (recipient === "Councilor") data.append("wardNo", wardNo);

      // userID from localstorage 
      data.append("user", localStorage.getItem("userId"));

      const res = await axios.post(
        "http://localhost:5000/complaints/submit",
        data,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );


      setMessage("✅ Complaint submitted successfully!");

      // ⏳ Wait 2 seconds before downloading the PDF
      setTimeout(() => {
        if (res.data.proofPdf) {
          const pdfUrl = `http://localhost:5000${res.data.proofPdf}`;
          const link = document.createElement("a");
          link.href = pdfUrl;
          link.setAttribute(
            "download",
            `Complaint-${res.data.complaint.serialNo}.pdf`
          );
          document.body.appendChild(link);
          link.click();
          link.remove();
        }
      }, 2000);



      // Reset form
      setComplaint("");
      setRecipient("");
      setWardNo("");
      setPdfFile(null);

    } catch (err) {
      console.error("❌ Error submitting complaint:", err.response?.data || err.message);


      const status = err.response?.status;
      const errorMsg = err.response?.data?.error;
      
      if (status === 401) {
    setMessage("⚠️ Please log in again to continue.");
    localStorage.clear();
    setTimeout(() => {
      navigate("/login");
    }, 1500);

  } else if (status === 404 && errorMsg?.toLowerCase().includes("profile not found")) {
    alert("⚠️ Please create your profile first.");
    navigate("/userprofile");   // 👈 must match App.js route exactly

  } else {
    setMessage(`❌ Failed: ${errorMsg || err.message}`);
  }
}
      
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 to-teal-400">
      <div className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-2xl space-y-6">


        {/* ✅ Display full user profile at the top if exists */}
        {userProfile && (
          <div className="bg-blue-100 p-4 rounded-lg mb-4">
            <h3 className="font-bold text-3xl text-blue-700 mb-2">Your Profile</h3>
            {userProfile.image && (
              <img src={`http://localhost:5000${userProfile.image}`} alt=" UserProfile image" className="w-20 h-20 rounded-full mb-2" />
            )}
            <p><strong>Full Name:</strong> {userProfile.fullName}</p>
            <p><strong>Email:</strong> {userProfile.email}</p>
            <p><strong>Mobile:</strong> {userProfile.mobile}</p>
            <p><strong>Ward No:</strong> {userProfile.wardNo}</p>
            <p><strong>House No:</strong> {userProfile.houseNo || "-"}</p>
            <p><strong>Street:</strong> {userProfile.street || "-"}</p>
            <p><strong>City:</strong> {userProfile.city || "-"}</p>
            <p><strong>Date of Birth:</strong> {userProfile.dob ? new Date(userProfile.dob).toLocaleDateString() : "-"}</p>
            <p><strong>Gender:</strong> {userProfile.gender || "-"}</p>
            {userProfile.voterIdImage && (
              <p>
                <strong>Voter ID Image:</strong>{" "}
                <img src={`http://localhost:5000${userProfile.voterIdImage}`} alt="Voter ID" className="w-32 h-20 object-cover mt-1 rounded-md" />
              </p>
            )}
          </div>
        )}

        {message && (
          <div
            className={`p-3 rounded text-center font-semibold ${message.includes("✅")
              ? "bg-green-700 text-white"
              : "bg-red-200 text-red-800"
              }`}
          >
            {message}
          </div>
        )}




        {/*complaint form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <h2 className="text-2xl font-bold text-blue-600">Complaint Form</h2>

          {/* Recipient */}
          <div>
            <label className="block text-gray-700 font-medium">Select Recipient</label>
            <select
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="w-full mt-1 p-3 border rounded-lg"
              required
            >
              <option value="">-- Select --</option>
              <option value="Councilor">Councilor</option>
              <option value="Mayor">Mayor</option>
              <option value="Commissioner">Municipal Commissioner</option>
            </select>
          </div>

          {/* WardNo (for Councilor only) */}
          {recipient === "Councilor" && (
            <div>
              <label className="block text-gray-700 font-medium">Select Ward No</label>
              <select
                value={wardNo}
                onChange={(e) => setWardNo(e.target.value)}
                className="w-full mt-1 p-3   border rounded-lg"
                required
              >
                <option value="">-- Select Ward --</option>
                <option value="1">Ward 1</option>
                <option value="2">Ward 2</option>
                <option value="3">Ward 3</option>
                <option value="4">Ward 4</option>
                <option value="5">Ward 5</option>
              </select>
            </div>
          )}

          {/* Complaint */}
          <div>
            <label className="block text-gray-700 font-medium">Complaint</label>
            <textarea
              value={complaint}
              onChange={(e) => setComplaint(e.target.value)}
              rows="5"
              placeholder="Enter your complaint with detailed........."
              className="w-full mt-1 p-3 border rounded-lg"
              required
            />
          </div>


           {/* PDF Upload (required for Mayor or Commissioner) */}
          {(recipient === "Mayor" || recipient === "Commissioner") && (
            <div>
              <label className="block text-gray-700 font-medium">
                Upload Supporting Document <b>(PDF only, mandatory)</b>
              </label>
              <p className="text-sm text-gray-500">
                Please attach a relevant supporting PDF document for your complaint.
              </p>
              <input
                type="file"
                accept="application/pdf"
                onChange={(e) => setPdfFile(e.target.files[0])}
                className="w-full mt-1 p-2 border rounded-lg"
                required
              />
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-800 transition"
          >
            Submit Complaint
          </button>
        </form>

      </div>
    </div>
  );
};

export default Complaint;
