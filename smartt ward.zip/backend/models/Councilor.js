// models/Councilor.js
const mongoose = require("mongoose");

const councilorSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  wardNo: Number
});

module.exports = mongoose.model("Councilor", councilorSchema);
