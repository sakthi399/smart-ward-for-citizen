const mongoose = require("mongoose");

const UserProfileSchema = new mongoose.Schema({
  fullName: { type: String, required: true },
  wardNo: { type: Number, required: true },
  houseNo: String,
  street: String,
  city: String,
  dob: { type: Date },
  gender: String,
  mobile: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  

  voterIdImage: { type: String, required: true, unique: true }, // path to uploaded file
  image: { type: String }, // path to uploaded file
}, { timestamps: true});


module.exports = mongoose.model("UserProfile", UserProfileSchema);
