const mongoose = require("mongoose");

const SignupSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  mobile_no: { type: String },
  password: { type: String, required: true },
  role: { type: String, enum: ["Mayor", "Commissioner", "Councilor", "User", "Admin"], default: "User" },
  wardNo: { type: Number }, // only for councilors
});

module.exports = mongoose.model("Signup", SignupSchema);
