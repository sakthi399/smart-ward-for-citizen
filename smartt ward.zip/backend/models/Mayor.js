// models/Mayor.js
const mongoose = require("mongoose");

const mayorSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String
});

module.exports = mongoose.model("Mayor", mayorSchema);
