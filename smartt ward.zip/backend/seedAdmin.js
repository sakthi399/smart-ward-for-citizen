const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
require("dotenv").config();

const User = require("./models/signup"); // your signup model

async function seedAdmin() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ Connected to MongoDB");

    // Predefined admin accounts
    const admins = [
      { email: "mayor@gmail.com", mobile_no: "9000000001", password: "mayor456", role: "Mayor" },
      { email: "commissioner@gmail.com", mobile_no: "9000000002", password: "commissioner789", role: "Commissioner" },
    ];

    // Add 5 councilors with ward numbers
    for (let i = 1; i <= 5; i++) {
      admins.push({
        email: `councilor${i}@gmail.com`,
        mobile_no: `900000000${i + 2}`, // just making different numbers
        password: `councilor${i}123`,
        role: "Councilor",
        wardNo: i, // ✅ ward assignment
      });
    }

    for (let admin of admins) {
      const existing = await User.findOne({ email: admin.email });
      if (existing) {
        console.log(`⚠️ ${admin.role} already exists: ${admin.email}`);
        continue;
      }

      const hashedPassword = await bcrypt.hash(admin.password, 10);
      const newAdmin = new User({
        email: admin.email,
        mobile_no: admin.mobile_no,
        password: hashedPassword,
        role: admin.role,
        wardNo: admin.wardNo || null, // ✅ only councilors will have ward
      });

      await newAdmin.save();
      console.log(`✅ ${admin.role} created: ${admin.email} ${admin.wardNo ? `(Ward ${admin.wardNo})` : ""}`);
    }

    mongoose.connection.close();
    console.log("🌟 Seeding completed, DB connection closed");
  } catch (err) {
    console.error("❌ Error seeding admins:", err);
    mongoose.connection.close();
  }
}

seedAdmin();
