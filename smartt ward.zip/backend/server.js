const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();
const path = require("path");
const jwt = require("jsonwebtoken");
const auth = require("./middleware/auth");
const bcrypt = require("bcrypt");



const app = express();

// ---------------- MIDDLEWARE ----------------
const allowedOrigins = [
  "http://localhost:5173", // user frontend
  "http://localhost:5174", // admin frontend
];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error("❌ Not allowed by CORS: " + origin));
      }
    },
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true,
  })
);

app.use(express.json());
app.use("/uploads", express.static("uploads"));

// ---------------- ROUTES ----------------
app.use("/councilor", require("./routes/CouncilorRoutes"));
app.use("/mayor", require("./routes/mayorRoutes"));
app.use("/commissioner", require("./routes/commissionerRoutes"));
app.use("/", require("./routes/signupRoutes"));
app.use("/complaints", require("./routes/complaintRoutes"));
app.use("/profiles", require("./routes/userRoutes")); // ✅ use userRoutes for profiles
app.use("/feedbacks", require("./routes/feedbackRoutes"));
app.use("/users", require("./routes/userRoutes"));
app.use("/admin", require("./routes/adminAuth"));


// ---------------- MONGODB ----------------
mongoose
  .connect(process.env.MONGO_URI)
  .then(async () => {
    console.log("✅ MongoDB Connected");

    // ---------------- MODELS ----------------
    const UserProfile = require("./models/Userprofile");
    const adminAuthRoute = require("./routes/adminAuth"); // make sure path is correct

    // Sync indexes to make sure email and voterIdImage are unique
    await UserProfile.syncIndexes();
    console.log("✅ UserProfile indexes synced");
  })
  .catch((err) => console.error("❌ MongoDB Error:", err));





// ---------------- START SERVER ----------------
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
