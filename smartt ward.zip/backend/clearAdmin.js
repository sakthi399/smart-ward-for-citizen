const mongoose = require("mongoose");
require("dotenv").config();

const User = require("./models/signup"); // adjust if your model path differs

async function clearAdmin() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ Connected to MongoDB");

    // Delete only Mayor, Councilor, Commissioner
    const result = await User.deleteMany({
      role: { $in: ["Mayor", "Councilor", "Commissioner"] }
    });

    console.log(`🗑️ Deleted ${result.deletedCount} admin(s)`);
    mongoose.connection.close();
  } catch (err) {
    console.error("❌ Error clearing admins:", err);
    mongoose.connection.close();
  }
}

clearAdmin();
