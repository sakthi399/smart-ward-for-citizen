const express = require('express');
const router = express.Router();
const Feedback = require('../models/feedback');

// POST feedback
router.post('/', async (req, res) => {
  try {
    const { email , feedback } = req.body;
    const newFeedback = new Feedback({ email, feedback });
    await newFeedback.save();
    res.json({ message: '✅ Feedback submitted successfully!' });
  } catch (error) {
    res.status(500).json({ message: '❌ Error submitting feedback' });
  }
});

// GET feedbacks
router.get('/', async (req, res) => {
  try {
    const feedbacks = await Feedback.find();
    res.json(feedbacks);
  } catch (error) {
    res.status(500).json({ message: '❌ Error fetching feedbacks' });
  }
});

module.exports = router;
