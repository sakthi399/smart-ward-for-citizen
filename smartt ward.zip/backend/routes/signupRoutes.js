const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Signup = require("../models/signup");

// ---------------- SIGNUP ----------------
router.post("/signup", async (req, res) => {
  try {
    const { email, mobile_no, password, role } = req.body;

    // check if user exists
    const existingUser = await Signup.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already exists" });
    }

    // hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // create new user
    const newUser = new Signup({
      email,
      mobile_no,
      password: hashedPassword,
      role: role || "User", // default role if not provided
    });

    await newUser.save();

    res.status(201).json({
      message: "User registered successfully ✅",
      user: { email: newUser.email, role: newUser.role },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ---------------- LOGIN ----------------
router.post("/login", async (req, res) => {
  try {
    const { email, password, wardNo } = req.body;

    const user = await Signup.findOne({ email });
    if (!user) return res.status(401).json({ message: " ❌ Invalid credentials" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ message: " ❌ Invalid credentials" });

    // ✅ Ensure councilor selects correct ward
    const wardNoIncoming = req.body.wardNo ? Number(req.body.wardNo) : undefined;
    if (user.role === "Councilor" && user.wardNo !== wardNoIncoming) {
      return res.status(401).json({ message: "Wrong ward selected" });
    }


    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role, wardNo: user.wardNo },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.json({
      message: "Login successful ✅",
      token,
      user: { _id:user._id, email: user.email, role: user.role, wardNo: user.wardNo },
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


// ---------------- ADMIN LOGIN (Passkey-based) ----------------
router.post("/admin-login", async (req, res) => {
  try {
    const { passkey } = req.body;

    // You can store this securely in your .env file
    if (passkey !== process.env.ADMIN_PASSKEY) {
      return res.status(401).json({ message: "❌ Invalid admin passkey" });
    }

    // Create a temporary admin token
    const token = jwt.sign(
      {  role: "Admin" },
      process.env.JWT_SECRET,
      { expiresIn: "8h" }
    );

    res.json({
      message: "✅ Admin login successful",
      token,
      user: { role: "Admin", email: "admin@system.local" },
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});



// ---------------- GET ALL USERS ----------------
router.get("/signup", async (req, res) => {
  try {
    const signups = await Signup.find();
    res.json(signups);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
