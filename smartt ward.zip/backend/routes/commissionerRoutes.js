const express = require("express");
const router = express.Router();
const Complaint = require("../models/Complaint");
const auth = require("../middleware/auth");

// Commissioner sees complaints with PDF only
router.get("/complaints", auth(["Commissioner"]), async (req, res) => {
  try {
    const complaints = await Complaint.find({
      recipientType: "Commissioner",
    }).sort({ createdAt: -1 });

    res.json(complaints);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
