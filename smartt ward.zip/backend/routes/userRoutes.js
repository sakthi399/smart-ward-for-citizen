const express = require("express");
const bcrypt = require("bcrypt");
const multer = require("multer");
const path = require("path");
const UserProfile = require("../models/Userprofile");
const upload = require("../middleware/upload"); // ✅ single import
const authenticate = require("../middleware/auth"); // ✅ import auth middleware
const Signup = require("../models/signup");


const router = express.Router();

// ✅ Create User Profile
router.post(
  "/create",   // 👈 only "/create" (not "/profiles/create")
  upload.fields([
    { name: "image", maxCount: 1 },
    { name: "voterIdImage", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const newProfile = new UserProfile({
        ...req.body,
        image: req.files?.image
          ? `/uploads/${req.files.image[0].filename}`
          : null,
        voterIdImage: req.files?.voterIdImage
          ? `/uploads/${req.files.voterIdImage[0].filename}`
          : null,
      });

      await newProfile.save();
      res.json({ success: true, profile: newProfile });
    } catch (err) {
      console.error("Profile create error:", err);

      if (err.code === 11000) {
        if (err.keyPattern?.email) {
          return res.status(400).json({ error: "Email already exists" });
        }
        if (err.keyPattern?.voterIdImage) {
          return res.status(400).json({ error: "Voter ID already exists" });
        }
      }

      res.status(500).json({ error: "Something went wrong, try again." });
    }
  }
);

// ✅ Change Password
router.put("/change-password", authenticate(), async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword) {
      return res.status(400).json({ message: "Both old and new passwords are required" });
    }

    // Find logged-in user
    const user = await Signup.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "User not found" });

    // Compare old password
    const isMatch = await bcrypt.compare(oldPassword, user.password);
    if (!isMatch) return res.status(400).json({ message: "Old password is incorrect" });

    // Hash and update new password
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(newPassword, salt);

    await user.save();

    res.json({ message: "✅ Password changed successfully" });
  } catch (err) {
    console.error("Change password error:", err);
    res.status(500).json({ message: "Server error" });
  }
});
   
    



// ✅ Get All Profiles
router.get("/", async (req, res) => {
  try {
    const users = await UserProfile.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET logged-in user's profile
router.get("/me", authenticate(), async (req, res) => {
  try {
    const profile = await UserProfile.findOne({ email: req.user.email });
    if (!profile) {
      return res.status(404).json({ message: "Profile not found" });
    }
    res.json(profile);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ NEW: Get any user profile by ID (for Councilor/Admin dashboard)
router.get("/:id", authenticate(["Admin", "Councilor","Mayor","Commissioner"]), async (req, res) => {
  try {
    const user = await UserProfile.findById(req.params.id).select("-__v");
    if (!user) {
      return res.status(404).json({ message: "User profile not found" });
    }
    res.json(user);
  } catch (err) {
    console.error("User profile fetch error:", err);
    res.status(500).json({ message: "Server error" });
  }
});


//put request for updating user profile

// Update existing profile
router.put(
  "/update",
  authenticate(),
  upload.fields([
    { name: "image", maxCount: 1 },
    { name: "voterIdImage", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const profile = await UserProfile.findOne({ email: req.user.email });
      if (!profile) return res.status(404).json({ message: "Profile not found" });

      // Update fields
      Object.keys(req.body).forEach((key) => {
        profile[key] = req.body[key];
      });

      // Update images if provided
      if (req.files?.image) profile.image = `/uploads/${req.files.image[0].filename}`;
      if (req.files?.voterIdImage) profile.voterIdImage = `/uploads/${req.files.voterIdImage[0].filename}`;

      await profile.save();
      res.json({ success: true, profile });
    } catch (err) {
      console.error("Profile update error:", err);
      res.status(500).json({ message: "Something went wrong" });
    }
  }
);


// this two for admin dashboard update and delete user profile
// ✅ Update profile
router.put("/:id", async (req, res) => {
  try {
    const updated = await UserProfile.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!updated) return res.status(404).json({ error: "Profile not found" });
    res.json(updated);
  } catch (err) {
    console.error("Update profile error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// ✅ Delete profile
router.delete("/:id", async (req, res) => {
  try {
    const deleted = await UserProfile.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Profile not found" });
    res.json({ message: "Profile deleted successfully" });
  } catch (err) {
    console.error("Delete profile error:", err);
    res.status(500).json({ error: "Server error" });
  }
});


// ---------------- ADMIN LOGIN (Passkey-based) ----------------
router.post("/admin-login", async (req, res) => {
  try {
    const { passkey } = req.body;

    // You can store this securely in your .env file
    if (passkey !== process.env.ADMIN_PASSKEY) {
      return res.status(401).json({ message: "❌ Invalid admin passkey" });
    }

    // Create a temporary admin token
    const token = jwt.sign(
      { id: "admin-unique-id", email: "admin@system.local", role: "Admin" },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.json({
      message: "✅ Admin login successful",
      token,
      user: { role: "Admin", email: "admin@system.local" },
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});





module.exports = router;

