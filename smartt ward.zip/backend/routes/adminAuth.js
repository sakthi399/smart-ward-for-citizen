// routes/adminAuth.js
const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");

const ADMIN_PASSKEY = "12345"; // same as frontend

router.post("/login-passkey", (req, res) => {
  const { passkey } = req.body;
  if (passkey !== ADMIN_PASSKEY) {
    return res.status(401).json({ message: "Invalid passkey" });
  }

  // Create a JWT token for admin
  const token = jwt.sign(
    { role: "Admin" },
    process.env.JWT_SECRET,
    { expiresIn: "8h" } // set a long enough expiry
  );

  res.json({
    success: true,
    token,
    user: { role: "Admin" },
  });
});

module.exports = router;
