const express = require("express");
const router = express.Router();
const Complaint = require("../models/Complaint");
const UserProfile = require("../models/Userprofile");
const auth = require("../middleware/auth");

// ✅ GET: All complaints for Mayor
router.get("/complaints", auth(["Mayor"]), async (req, res) => {
  try {
    const complaints = await Complaint.find()
      .populate("user", "-__v") // populate user details
      .sort({ createdAt: -1 });
    res.json(complaints);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// ✅ GET: Single user profile by ID
router.get("/users/:id", auth(["Admin", "Councilor", "Mayor"]), async (req, res) => {
  try {
    const user = await UserProfile.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "User profile not found" });
    res.json(user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
