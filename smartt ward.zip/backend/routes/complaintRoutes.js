const express = require("express");
const router = express.Router();
const Complaint = require("../models/Complaint");
const auth = require("../middleware/auth");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const PDFDocument = require("pdfkit");

// Ensure folders exist
const uploadDir = path.join(__dirname, "../uploads/complaints");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer setup for manual uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

// ✅ POST: Submit Complaint (manual upload + auto PDF proof)
router.post("/submit", auth(), upload.single("pdfFile"), async (req, res) => {
  try {
    const { complaint, recipientType, wardNo } = req.body;

    if (!recipientType || !complaint) {
      return res.status(400).json({
        error: "Recipient type and complaint are required",
      });
    }

     // 1️⃣ Check if user has a profile
    const UserProfile = require("../models/Userprofile");
    const userProfile = await UserProfile.findOne({ email: req.user.email });

    if (!userProfile) {
      return res.status(404).json({
        error: "Profile not found. Please create your profile first.",
      });
    }

    // 1️⃣ Get last serial number
    const lastComplaint = await Complaint.findOne().sort({ serialNo: -1 });
    const nextSerial = lastComplaint && !isNaN(Number(lastComplaint.serialNo))
    ?Number(lastComplaint.serialNo) + 1
    : 1;

    // 2️⃣ Save complaint with uploaded file (if any)
    const newComplaint = new Complaint({
      serialNo: nextSerial,  // ✅ Auto-increment serial number
      complaint,
      recipientType,
      wardNo: recipientType === "Councilor" ? wardNo : undefined,
      pdfFile: req.file ? `/uploads/complaints/${req.file.filename}` : null, // manual PDF
      status: "Pending",
      user: userProfile._id, // link to user profile
    });
    await newComplaint.save();

   
    // 4️⃣ Create PDF proof
    const proofPath = path.join(uploadDir, `${nextSerial}_proof.pdf`);
    const doc = new PDFDocument({ size: "A4", margin: 50 });
    const writeStream = fs.createWriteStream(proofPath);
    doc.pipe(writeStream);

    // ---- HEADER ----
    doc.fontSize(25).text(" Smart Ward Complaint Proof Document", { underline: true , align: "center" });
    doc.moveDown();

    // Serial No + Timestamp
    doc.fontSize(17).text(`Complaint Serial No:- ${nextSerial}`);
    doc.text(`Complaint ID:- ${newComplaint._id}`);
    doc.text(`Date & Time:- ${new Date().toLocaleString()}`);
    doc.moveDown(1);

    // ---- USER DETAILS ----
    doc.fontSize(18).text("User Details:-", { underline: true });
    doc.fontSize(14).text(`Full Name:- ${userProfile.fullName}`);
    doc.text(`Email:- ${userProfile.email}`);
    doc.text(`Mobile:- ${userProfile.mobile}`);
    doc.text(`Ward No:- ${userProfile.wardNo || "-"}`);
    doc.text(`House No:- ${userProfile.houseNo || "-"}`);
    doc.text(`Street:- ${userProfile.street || "-"}`);
    doc.text(`City:- ${userProfile.city || "-"}`);
    doc.text(`Date of Birth:- ${userProfile.dob ? new Date(userProfile.dob).toLocaleDateString() : "-"}`);
    doc.text(`Gender:- ${userProfile.gender || "-"}`);

    // Render Profile Image if exists
if (userProfile.image) {
  const profileImagePath = path.join(__dirname, "..", userProfile.image);
  if (fs.existsSync(profileImagePath)) {
    doc.moveDown();
    doc.text(" User Profile Image:-");
    doc.image(profileImagePath, { width: 100, height: 100 }); // adjust size
  }
}

// Render Voter ID Image if exists
if (userProfile.voterIdImage) {
  const voterImagePath = path.join(__dirname, "..", userProfile.voterIdImage);
  if (fs.existsSync(voterImagePath)) {
    doc.moveDown();
    doc.text(" User Voter ID Image:-");
    doc.image(voterImagePath, { width: 200, height: 100 }); // adjust size
  }
}

doc.moveDown();
   
    // ---- COMPLAINT DETAILS ----
    doc.fontSize(18).text("Complaint Details :-", { underline: true });
    doc.fontSize(15).text(`Recipient:- ${recipientType}`);
    if (wardNo) doc.text(`Ward No:- ${wardNo}`);
    doc.moveDown(0.5);
    doc.fontSize(18).text(" User Complaint :-", { underline: true });
    doc.text(complaint, { align: "justify" });

    // ---- FOOTER ----
    doc.moveDown(2);
    doc.fontSize(10).text("This is a system-generated document and can be used as proof.", {
      align: "center",
      underline: true,
    });

    doc.end();


    

    // 5️⃣ Save PDF path
    writeStream.on("finish", async () => {
    newComplaint.proofPdf = `/uploads/complaints/${nextSerial}_proof.pdf`;
    await newComplaint.save();

    res.status(201).json({
      success: true,
      message: "✅ Complaint submitted successfully",
      complaint: newComplaint,
      manualPdf: newComplaint.pdfFile,   // if user uploaded
      proofPdf: newComplaint.proofPdf,   // auto generated proof
    });
  });
  writeStream.on("error", (err) => {
    console.error("PDF write error:", err);
    res.status(500).json({ error: "Failed to generate PDF" });
  });
  
  } catch (err) {
    console.error("Complaint submit error:", err);
    res.status(500).json({ error: "Server error" });
  }
});


//  for admin delete complaint and pdf
router.get("/all", auth(["Admin"]), async (req, res) => {
  try {
    const complaints = await Complaint.find().sort({ createdAt: -1 });
    res.json(complaints);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});




// ✅ GET: Complaints filtered by role
router.get("/", auth(["Mayor", "Councilor", "Commissioner"]), async (req, res) => {
  try {
    const role = req.user.role;
    let complaints = [];

    if (role === "Mayor" || role === "Commissioner") {
      complaints = await Complaint.find({ recipientType: role })
        .populate(
          "user",
          "fullName wardNo houseNo streetName city dob gender mobileNo email voterId image"
        )
        .sort({ createdAt: -1 });
    } else if (role === "Councilor") {
      if (!req.user.wardNo) {
        return res.status(400).json({ error: "Ward number missing in token" });
      }
      complaints = await Complaint.find({
        recipientType: "Councilor",
        wardNo: req.user.wardNo,
      })
        .populate(
          "user",
          "fullName wardNo houseNo streetName city dob gender mobileNo email voterId image"
        )
        .sort({ createdAt: -1 });
    }


    res.json(complaints);
  } catch (err) {
    console.error("Complaint fetch error:", err);
    res.status(500).json({ error: err.message });
  }
});

// GET: Serve generated PDF by complaint ID
router.get("/:id/pdf", auth(), async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id);
    if (!complaint || !complaint.proofPdf) {
      return res.status(404).json({ error: "PDF not found" });
    }

    const pdfPath = path.join(__dirname, "..", complaint.proofPdf); // full path
    if (!fs.existsSync(pdfPath)) {
      return res.status(404).json({ error: "PDF file not found on server" });
    }

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=Complaint-${complaint.serialNo}.pdf`
    );
    fs.createReadStream(pdfPath).pipe(res);
  } catch (err) {
    console.error("PDF fetch error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// Delete complaint by ID admin only
router.delete("/:id", auth(["Admin"]), async (req, res) => {
  try {
     console.log("Deleting complaint ID:", req.params.id);
    const complaint = await Complaint.findById(req.params.id);
    console.log("Complaint found:", complaint);
    if (!complaint) return res.status(404).json({ message: "Complaint not found" });

    // Optional: Delete PDF file from server
    if (complaint.pdfFile) {
      const fs = require("fs");
      const path = require("path");
      const filePath = path.join(__dirname, "../", complaint.pdfFile);
      console.log("PDF file path:", filePath);

      if (fs.existsSync(filePath)) {
         fs.unlinkSync(filePath);
      console.log("PDF file deleted");
    }
  }

    await Complaint.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Complaint deleted successfully" });
  } catch (err) {
    console.error("Delete complaint error:",err);
    res.status(500).json({ message: "Server error" });
  }
});

// Delete only PDF from complaint
router.put("/:id/delete-pdf", auth(["Admin"]), async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) return res.status(404).json({ message: "Complaint not found" });

    if (complaint.pdfFile) {
      const fs = require("fs");
      const path = require("path");
      const filePath = path.join(__dirname, "../", complaint.pdfFile);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }

    complaint.pdfFile = null;
    await complaint.save();

    res.json({ success: true, message: "PDF deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});






module.exports = router;
