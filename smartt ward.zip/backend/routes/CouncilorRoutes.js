const express = require("express");
const router = express.Router();
const Complaint = require("../models/Complaint");
const auth = require("../middleware/auth");

router.get("/complaints", auth(["Councilor"]), async (req, res) => {
  try {
    const complaints = await Complaint.find({
      recipientType: "Councilor",
      wardNo: req.user.wardNo,
    })
      .populate("user", "fullName email wardNo houseNo street city dob gender mobile image voterIdImage") // populate user profile, exclude fields
      .sort({ createdAt: -1 });

    // optional: filter out complaints with null user
    const filteredComplaints = complaints.filter(c => c.user !== null);

    res.json(filteredComplaints);

    console.log("Complaints with user populated:", complaints);
    res.json(complaints);

  } catch (err) {
    console.error("Councilor complaints fetch error:", err);
    res.status(500).json({ error: "Server error" });
  }
});


module.exports = router;
