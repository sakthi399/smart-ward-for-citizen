import { Routes, Route, BrowserRouter } from "react-router-dom";
import AdminDashboard from "./pages/AdminDashboard";
import AdminHome from "./pages/AdminHome";
import AdminLogin from "./pages/AdminLogin";
import CouncilorDashboard from "./pages/CouncilorDashboard";
import MayorDashboard from "./pages/MayorDashboard";
import CommissionerDashboard from "./pages/CommissionerDashboard";
import logo from './assets/logo.jpg'
import AdminFeedbackPage from "./pages/AdminFeedbackPage";
import AdminComplaints from "./pages/AdminComplaints";


function App() {
  return (
    
     
              
    
    <Routes>
      <Route path="/" element={<AdminHome />} />
      <Route path="/login/:role" element={<AdminLogin />} />
      <Route path="/dashboard/councilor" element={<CouncilorDashboard />} />
      <Route path="/dashboard/mayor" element={<MayorDashboard />} />
      <Route path="/dashboard/commissioner" element={<CommissionerDashboard />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/feedback" element={<AdminFeedbackPage />} />
       <Route path="/complaints" element={<AdminComplaints />} /> 
    </Routes>

    
    
  );
}

export default App;
