import React, { useState } from "react";
import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <>
    

    <div className="w-64 h-screen bg-gray-800 text-white flex flex-col p-4">
      <h2 className="text-xl font-bold mb-6">Admin Panel</h2>

      {/* Mayor & Commissioner */}
      <Link
        to="/login/mayor"
        className="mb-2 p-2 rounded hover:bg-gray-700 block"
      >
        Mayor Login
      </Link>
      <Link
        to="/login/commissioner"
        className="mb-2 p-2 rounded hover:bg-gray-700 block"
      >
        Commissioner Login
      </Link>

      <Link
        to="/admin"
        className="mb-2 p-2 rounded hover:bg-gray-700 block"
      >
        Admin
      </Link>

      <Link
        to="/feedback"
        className="mb-2 p-2 rounded hover:bg-gray-700 block"
      >
        View Feedback
      </Link>

      <Link
        to="/complaints"
        className="mb-2 p-2 rounded hover:bg-gray-700 block"
      >
        Manage user Complaints
      </Link>



      {/* Councilors Dropdown */}
      <div className="mt-4">
        <h3 className="font-semibold mb-2">Councilors</h3>
        <div className="space-y-2">
          {[1, 2, 3, 4, 5].map((ward) => (
            <Link
              key={ward}
              to={`/login/councilor?ward=${ward}`}
              className="block p-2 rounded hover:bg-gray-700"
            >
              Councilor Ward {ward}
            </Link>
          ))}
        </div>
      </div>
    </div>
    </>
  );
};

export default Sidebar;
