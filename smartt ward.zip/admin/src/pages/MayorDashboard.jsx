import React, { useEffect, useState } from "react";
import api from "../utils/api";


const MayorDashboard = () => {
  const [complaints, setComplaints] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null); // for modal
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchComplaints = async () => {
      try {
        setLoading(true);
        const res = await api.get("/complaints"); // backend filters by role (Mayor)
        setComplaints(res.data);
      } catch (err) {
        console.error("Error fetching complaints:", err);
        alert("Failed to load complaints");
      } finally {
        setLoading(false);
      }
    };

    fetchComplaints();
  }, []);

  // Fetch user profile for modal
  const viewUserProfile = async (userId) => {
    try {
      const res = await api.get(`/profiles/${userId}`); // use /profiles/:id
      setSelectedUser(res.data);
    } catch (err) {
      alert(`Failed to load user profile: ${err.response?.data?.message || err.message}`);
    }
  };

  const closeModal = () => setSelectedUser(null);

  return (
   <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Mayor Dashboard</h1>

      {loading ? (
        <p>Loading complaints...</p>
      ) : complaints.length === 0 ? (
        <p>No complaints assigned to you.</p>
      ) : (
        <table className="w-full border-collapse border border-gray-300 ">
          <thead>
            <tr className="bg-gray-100">
              <th className="border px-4 py-2"> User REF</th>
              <th className="border px-4 py-2"> User Complaints</th>
              <th className="border px-4 py-2">From (User)</th>
            </tr>
          </thead>
          <tbody>
            {complaints.map((c) => (
              <tr key={c._id}>
                <td className="border px-4 py-2">
                  {c.user ? (
                    <div className="p-2 border rounded-lg bg-gray-50 shadow-lg">
                      <p><strong>{c.user.fullName}</strong></p>
                      <p>Ward: {c.user.wardNo}</p>
                    </div>
                  ) : "User details missing"}
                </td>
                <td className="border px-4 py-2">{c.complaint}</td>
                <td className="border px-4 py-2 space-x-2 ">
                  <button
                    onClick={() => viewUserProfile(c.user?._id)}
                    className=" bg-green-500 rounded-lg px-3 py-1 mb-3 hover:bg-green-600 text-white"
                    disabled={!c.user}
                  >
                    View User Profile
                  </button>
                  {c.pdfFile && (
                    <a
                      href={`http://localhost:5000${c.pdfFile}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className=" bg-blue-500 rounded-lg px-3 py-1   hover:bg-blue-600 text-white inline-block"
                    >
                      View User PDF
                    </a>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* User Profile Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96 relative">
            <button
              onClick={closeModal}
              className="absolute top-2 right-2 text-red-500 font-bold"
            >
              X
            </button>
            <h2 className="text-xl font-bold mb-4">User Profile</h2>
            {selectedUser.image && (
              <img
                src={`http://localhost:5000${selectedUser.image}`}
                alt="User"
                className="w-24 h-24 rounded-full mb-2"
              />
            )}
            <p><strong>Full Name:</strong> {selectedUser.fullName}</p>
            <p><strong>Ward No:</strong> {selectedUser.wardNo}</p>
            <p><strong>House No:</strong> {selectedUser.houseNo}</p>
            <p><strong>Street:</strong> {selectedUser.street}</p>
            <p><strong>City:</strong> {selectedUser.city}</p>
            <p><strong>DOB:</strong> {selectedUser.dob}</p>
            <p><strong>Gender:</strong> {selectedUser.gender}</p>
            <p><strong>Mobile:</strong> {selectedUser.mobile}</p>
            <p><strong>Email:</strong> {selectedUser.email}</p>
            {selectedUser.voterIdImage && (
              <div className="mt-2">
                <strong>Voter ID:</strong>
                <img
                  src={`http://localhost:5000${selectedUser.voterIdImage}`}
                  alt="Voter ID"
                  className="w-40 mt-1 border"

                />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
          

export default MayorDashboard;
