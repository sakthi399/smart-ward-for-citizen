import React from "react";
import { useNavigate } from "react-router-dom";

const AdminHome = () => {
  const navigate = useNavigate();

  const handleClick = (role) => {
    // redirect to login page with role info
    navigate(`/login/${role}`);
  };

  return (
    
              
    <div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-blue-700 text-white p-6 space-y-6">
        <h2 className="text-xl font-bold">Admin Panel</h2>
        <ul className="space-y-4">
          <li>
            <button
              className="w-full text-left hover:text-yellow-300"
              onClick={() => handleClick("councilor")}
            >
              Councilor
            </button>
          </li>
          <li>
            <button
              className="w-full text-left hover:text-yellow-300"
              onClick={() => handleClick("mayor")}
            >
              Mayor
            </button>
          </li>
          <li>
            <button
              className="w-full text-left hover:text-yellow-300"
              onClick={() => handleClick("commissioner")}
            >
              Municipal Commissioner
            </button>
          </li>

          <li>
            <button
              className="w-full text-left hover:text-yellow-300"
              onClick={() => navigate("/feedback")}
            >
              View User Feedback
            </button>
          </li>

          <li>
            <button
              className="w-full text-left hover:text-yellow-300"
              onClick={() => navigate("/admin")}
            >
              Admin Dashboard
            </button>
          </li>
        </ul>
      </div>



      {/* Content */}
      <div className="flex-1 p-8">
        <h1 className="text-3xl font-bold text-blue-700">Welcome to Admin Home</h1>
        <p className="mt-4 text-gray-600">Select a role from the sidebar to login and view complaints.</p>
      </div>
    </div>
    
  );
};

export default AdminHome;
