import React, { useState, useEffect } from "react";
import Sidebar from "../components/Sidebar";
import axios from "axios";



const AdminComplaints = ({ setSection }) => {
    const [complaints, setComplaints] = useState([]);

    // Fetch all complaints for Admin
   const fetchComplaints = async () => {
  try {
    const token = localStorage.getItem("token"); // make sure token exists
    if (!token) {
      console.error("No token found in localStorage");
      return;
    }

    const res = await axios.get("http://localhost:5000/complaints/all", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    console.log("Complaints array:", res.data);
    setComplaints(res.data);
  } catch (err) {
    console.error("Failed to fetch complaints:", err.response?.data || err);
  }
};


    useEffect(() => {
        fetchComplaints();
    }, []);

    // Delete complaint
    const handleDeleteComplaint = async (id) => {
        if (!window.confirm("Are you sure you want to delete this complaint?")) return;
        try {
            await axios.delete(`http://localhost:5000/complaints/${id}`, {
                headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
            });
            setComplaints(complaints.filter((c) => c._id !== id));
            alert("Complaint deleted ✅");
        } catch (err) {
            console.error(err);
            alert("❌ Failed to delete complaint");
        }
    };

    // Delete only PDF
    const handleDeletePdf = async (id) => {
        if (!window.confirm("Are you sure you want to delete this PDF?")) return;
        try {
            await axios.put(
                `http://localhost:5000/complaints/${id}/delete-pdf`,
                {},
                { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } }
            );
            setComplaints(
                complaints.map((c) => (c._id === id ? { ...c, pdfFile: null } : c))
            );
            alert("PDF deleted ✅");
        } catch (err) {
            console.error(err);
            alert("❌ Failed to delete PDF");
        }
    };

    return (
        <div className="flex">
            <Sidebar setSection={setSection} />
            <div className="flex-1 p-6">
                <h1 className="text-2xl font-bold mb-4">All Complaints</h1>

                <table className="w-full border text-sm">
                    <thead className="bg-gray-200">
                        <tr>
                            <th className="p-2">Serial No</th>
                            <th className="p-2">Recipient</th>
                            <th className="p-2">Complaint</th>
                            <th className="p-2">PDF</th>
                            <th className="p-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {complaints.map((c, index) => (
                            <tr key={c._id} className="border-t text-center">
                                <td className="p-2">{c.serialNo}</td>
                                <td className="p-2">{c.recipientType}</td>
                                <td className="p-2">{c.complaint}</td>
                                <td className="p-2">
                                    {c.pdfFile ? (
                                        <div className="flex flex-col items-center space-y-1">
                                            <a
                                                href={`http://localhost:5000${c.pdfFile}`}
                                                target="_blank"
                                                rel="noreferrer"
                                                className="text-white bg-blue-500 rounded-md hover:bg-blue-700"
                                            >
                                                View PDF
                                            </a>
                                            <button
                                                className="bg-red-600 hover:bg-red-800 text-white px-2 py-1 rounded text-sm"
                                                onClick={() => handleDeletePdf(c._id)}
                                            >
                                                Delete PDF
                                            </button>
                                        </div>
                                    ) : (
                                        <span>No PDF</span>
                                    )}
                                </td>
                                <td className="p-2 space-x-2">
                                    <button
                                        className="bg-red-600 hover:bg-red-800 text-white px-3 py-1 rounded"
                                        onClick={() => handleDeleteComplaint(c._id)}
                                    >
                                        Delete Complaint
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {complaints.length === 0 && (
                            <tr>
                                <td colSpan={5} className="p-4 text-gray-500">
                                    No complaints found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AdminComplaints;
