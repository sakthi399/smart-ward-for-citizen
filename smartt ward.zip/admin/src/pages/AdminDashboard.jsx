import React, { useState, useEffect } from "react";
import Sidebar from "../components/Sidebar";


import axios from "axios";
import { useNavigate } from "react-router-dom";

const AdminDashboard = () => {
  const [section, setSection] = useState("home");
  const [profiles, setProfiles] = useState([]);
  const [complaints, setComplaints] = useState([]);
  const [editProfile, setEditProfile] = useState(null);
  const [message, setMessage] = useState("");
  const [previewImage, setPreviewImage] = useState(null); // 🖼 for image preview

  // 🔑 Admin passkey states
  const [passkeyVerified, setPasskeyVerified] = useState(false);
  const [enteredKey, setEnteredKey] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const ADMIN_PASSKEY = "12345"; // simple static key
  const JWT_SECRET = "supersecretkey123"; // from your .env

  const navigate = useNavigate();

 useEffect(() => {
  if (section === "profiles") {
    const fetchProfiles = async () => {
      try {
        const res = await axios.get("http://localhost:5000/profiles", {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setProfiles(res.data);
      } catch (err) {
        console.error("Failed to fetch profiles:", err.response?.data || err);
      }
    };
    fetchProfiles();
  }
}, [section]);



  // ✅ Delete user profile
  const handleDeleteProfile = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user profile?")) return;
    try {
      await axios.delete(`http://localhost:5000/profiles/${id}`);
      setProfiles(profiles.filter((p) => p._id !== id));
      alert("Profile deleted ✅");
    } catch (err) {
      alert("❌ Failed to delete profile");
    }
  };

  // ✅ Update profile
  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/profiles/${editProfile._id}`, editProfile);
      alert("✅ Profile updated successfully!");
      setEditProfile(null);
      setSection("profiles");
    } catch (err) {
      alert("❌ Failed to update profile");
    }
  };

  // Delete complaint
  const handleDeleteComplaint = async (id) => {
    if (!window.confirm("Are you sure you want to delete this complaint?")) return;
    try {
      await axios.delete(`http://localhost:5000/complaints/${id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setComplaints(complaints.filter((c) => c._id !== id));
      alert("Complaint deleted ✅");
    } catch (err) {
      console.error(err);
      alert("❌ Failed to delete complaint");
    }
  };


  // Delete only PDF file from a complaint
  const handleDeletePdf = async (id) => {
    if (!window.confirm("Are you sure you want to delete this PDF?")) return;
    try {
      await axios.put(`http://localhost:5000/complaints/${id}/delete-pdf`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });

      // Update local state so table reflects deletion
      setComplaints(
        complaints.map((c) =>
          c._id === id ? { ...c, pdfFile: null } : c
        )
      );

      alert("PDF deleted ✅");
    } catch (err) {
      console.error(err);
      alert("❌ Failed to delete PDF");
    }
  };

  console.log("Complaints array:", complaints);



  // 🔑 Passkey check
  const handleVerifyPasskey = async () => {
  try {
    const res = await axios.post("http://localhost:5000/admin/login-passkey", {
      passkey: enteredKey,
    });

    localStorage.setItem("token", res.data.token);
    localStorage.setItem("role", res.data.user.role);
    setPasskeyVerified(true);
    setErrorMsg("");
  } catch (err) {
    setErrorMsg("❌ Incorrect Passkey");
  }
};

  // 🔐 Show passkey screen before dashboard
  if (!passkeyVerified) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="bg-white p-8 rounded-xl shadow-lg w-96 text-center">
          <h2 className="text-xl font-bold text-gray-700 mb-4">🔒 Admin Access</h2>
          <input
            type="password"
            placeholder="Enter Admin Passkey"
            value={enteredKey}
            onChange={(e) => setEnteredKey(e.target.value)}
            className="w-full border p-2 rounded mb-3"
          />
          <button
            onClick={handleVerifyPasskey}
            className="bg-blue-600 text-white w-full py-2 rounded hover:bg-blue-700 transition"
          >
            Enter Admin Dashboard
          </button>
          {errorMsg && <p className="text-red-600 mt-3">{errorMsg}</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="flex">
      <Sidebar setSection={setSection} />
      <div className="flex-1 p-6">
        {/* ✅ HOME SECTION */}
        {section === "home" && (
          <div>
            <h1 className="text-2xl mb-4 font-bold text-gray-700">Welcome, Admin 👋</h1>

            {/* ✅ Only 2 Boxes Now */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Create User */}
              <div
                className="p-6 bg-blue-500 text-white rounded-xl shadow hover:bg-blue-600 cursor-pointer"
                onClick={() => window.open("http://localhost:5173/signup", "_blank")}
              >
                <h2 className="text-xl font-semibold">👤 Create User</h2>
                <p className="text-sm mt-2">
                  Redirects to signup page to create a new user account
                </p>
              </div>

              {/* Manage Profiles */}
              <div
                className="p-6 bg-purple-500 text-white rounded-xl shadow hover:bg-purple-600 cursor-pointer"
                onClick={() => setSection("profiles")}
              >
                <h2 className="text-xl font-semibold">🧾 Manage Profiles</h2>
                <p className="text-sm mt-2">View, edit or delete user data</p>
              </div>
            </div>
          </div>
        )}

        {/* ✅ VIEW + EDIT PROFILES */}
        {section === "profiles" && (
          <div>
            <h1 className="text-xl mb-4 font-bold text-gray-700">User Profiles</h1>
            <table className="w-full border text-sm">
              <thead className="bg-gray-200">
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Ward</th>
                  <th>Image</th>
                  <th>Mobile no</th>
                  <th>Voter id</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {profiles.map((p) => (
                  <tr key={p._id} className="border-t text-center">
                    <td>{p.fullName}</td>
                    <td>{p.email}</td>
                    <td>{p.wardNo}</td>
                    <td>
                      {p.image && (
                        <img
                          src={`http://localhost:5000${p.image}`}
                          alt="profile"
                          className="w-12 h-12 mx-auto rounded-full cursor-pointer hover:scale-105 transition"
                          onClick={() => setPreviewImage(`http://localhost:5000${p.image}`)} // 🖼 click to preview
                        />
                      )}
                    </td>
                    <td>{p.mobile}</td>
                    <td>
                      {p.voterIdImage && (
                        <img
                          src={`http://localhost:5000${p.voterIdImage}`}
                          alt="voter id"
                          className="w-12 h-12 mx-auto rounded cursor-pointer hover:scale-105 transition"
                          onClick={() =>
                            setPreviewImage(`http://localhost:5000${p.voterIdImage}`)
                          }
                        />
                      )}
                    </td>
                    <td>
                      <button
                        className="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded mr-2"
                        onClick={() => setEditProfile(p)}
                      >
                        Edit
                      </button>
                      <button
                        className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded"
                        onClick={() => handleDeleteProfile(p._id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* 🖼 Image Preview Modal */}
            {previewImage && (
              <div
                className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50"
                onClick={() => setPreviewImage(null)}
              >
                <img
                  src={previewImage}
                  alt="Preview"
                  className="max-w-lg max-h-[80vh] rounded-lg shadow-lg border-4 border-white"
                />
              </div>
            )}

            {/* ✅ Edit Profile Modal */}
            {editProfile && (
              <div className="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center">
                <div className="bg-white p-6 rounded-xl shadow-lg w-96">
                  <h3 className="text-lg font-bold mb-3">Edit Profile</h3>
                  <form onSubmit={handleUpdateProfile} className="space-y-2">
                    <input
                      type="text"
                      className="w-full border p-2 rounded"
                      value={editProfile.fullName}
                      onChange={(e) =>
                        setEditProfile({ ...editProfile, fullName: e.target.value })
                      }
                    />
                    <input
                      type="email"
                      className="w-full border p-2 rounded"
                      value={editProfile.email}
                      onChange={(e) =>
                        setEditProfile({ ...editProfile, email: e.target.value })
                      }
                    />
                    <input
                      type="text"
                      className="w-full border p-2 rounded"
                      value={editProfile.wardNo}
                      onChange={(e) =>
                        setEditProfile({ ...editProfile, wardNo: e.target.value })
                      }
                    />
                    <input
                      type="text"



                      className="w-full border p-2 rounded"
                      value={editProfile.mobile}
                      onChange={(e) =>
                        setEditProfile({ ...editProfile, mobile: e.target.value })
                      }
                    />
                    <div className="flex justify-end mt-3 space-x-2">
                      <button
                        type="button"
                        className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                        onClick={() => setEditProfile(null)}
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded"
                      >
                        Update
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        
      </div>
    </div>

  );
};

export default AdminDashboard;
