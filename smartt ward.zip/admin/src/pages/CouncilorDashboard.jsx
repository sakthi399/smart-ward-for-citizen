import React, { useEffect, useState } from "react";
import api from "../utils/api";

const CouncilorDashboard = () => {
  const [complaints, setComplaints] = useState([]);
  const [expanded, setExpanded] = useState({});
  const [selectedUser, setSelectedUser] = useState(null); // for modal
  const [loading, setLoading] = useState(true);

  // Fetch complaints
  useEffect(() => {
    const fetchComplaints = async () => {
      try {
        setLoading(true);
        const res = await api.get("/complaints");
        setComplaints(res.data);
      } catch (err) {
        if (err.response?.status === 401) {
          alert("Session expired. Please log in again.");
          localStorage.removeItem("token");
          window.location.href = "/login";
        } else {
          alert(`Failed to load complaints: ${err.response?.data?.message || err.message}`);
        }
      } finally {
        setLoading(false);
      }
    };

    fetchComplaints();
  }, []);

  const toggleExpand = (id) => {
    setExpanded((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Fetch user profile when "View Profile" is clicked
  const viewUserProfile = async (userId) => {
    try {
      const res = await api.get(`/profiles/${userId}`);
      setSelectedUser(res.data);
    } catch (err) {
      alert(`Failed to load user profile: ${err.response?.data?.message || err.message}`);
    }
  };

  const closeModal = () => setSelectedUser(null);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Councilor Dashboard</h1>

      {loading ? (
        <p>Loading complaints...</p>
      ) : complaints.length === 0 ? (
        <p>No complaints assigned.</p>
      ) : (
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr className="bg-gray-100">
              <th className="border px-4 py-2">User REF</th>
              <th className="border px-4 py-2">User Complaints</th>
              <th className="border px-4 py-2">From (User)</th>
            </tr>
          </thead>
          <tbody>
            {complaints.map((c) => (
  <React.Fragment key={c._id}>
    <tr>
      {/* Display user name and ward number directly */}
      <td className="border px-4 py-2 ">
        {c.user ? (
          <div className="p-2 border rounded-lg bg-gray-50 shadow-lg">
            <p><strong>{c.user.fullName}</strong></p>
            <p>Ward: {c.user.wardNo}</p>
          </div>
        ) : (
          <span className="text-red-500">User profile not found</span>
        )}
      </td>

      {/* Complaint text */}
      <td className="border px-4 py-2">{c.complaint}</td>

      {/* Actions */}
      <td className="border px-4 py-2 space-x-1">
        <button
          onClick={() => toggleExpand(c._id)}
          className="   bg-blue-500 text-white px-3 py-2  mb-3 rounded-lg hover:bg-blue-600"
        >
          {expanded[c._id] ? "Hide Complaint Details" : "View Complaint Details"}
        </button>
        <button
          onClick={() => c.user && viewUserProfile(c.user._id)}
          className=" bg-green-600 text-white px-3 py-2 rounded-lg inline-block"
          disabled={!c.user}
        >
          View User Profile
        </button>
      </td>
    </tr>

    {expanded[c._id] && (
      <tr>
        <td colSpan={3} className="border px-4 py-2 bg-gray-50">
          <p><strong>Status:</strong> {c.status}</p>
          <p><strong>Assigned Ward:</strong> {c.wardNo}</p>
        </td>
      </tr>
    )}
  </React.Fragment>
))}

          </tbody>
        </table>
      )}

      {/* User Profile Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 w-96 relative">
            <button
              onClick={closeModal}
              className="absolute top-2 right-2 text-red-500 font-bold"
            >
              X
            </button>
            <h2 className="text-xl font-bold mb-4">User Profile</h2>
            {selectedUser.image && (
              <img
                src={`http://localhost:5000${selectedUser.image}`}
                alt="User"
                className="w-24 h-24 rounded-full mb-2"
              />
            )}
            <p><strong>Full Name:</strong> {selectedUser.fullName}</p>
            <p><strong>Ward No:</strong> {selectedUser.wardNo}</p>
            <p><strong>House No:</strong> {selectedUser.houseNo}</p>
            <p><strong>Street:</strong> {selectedUser.street}</p>
            <p><strong>City:</strong> {selectedUser.city}</p>
            <p><strong>DOB:</strong> {selectedUser.dob}</p>
            <p><strong>Gender:</strong> {selectedUser.gender}</p>
            <p><strong>Mobile:</strong> {selectedUser.mobile}</p>
            <p><strong>Email:</strong> {selectedUser.email}</p>
            {selectedUser.voterIdImage && (
              <div className="mt-2">
                <strong>Voter ID:</strong>
                <img
                  src={`http://localhost:5000${selectedUser.voterIdImage}`}
                  alt="Voter ID"
                  className="w-40 mt-1 border"
                />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CouncilorDashboard;
