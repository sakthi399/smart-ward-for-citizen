import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminFeedbackPage = () => {
  const [feedbacks, setFeedbacks] = useState([]); // make sure default is an array
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeedbacks = async () => {
      try {
        const res = await axios.get("http://localhost:5000/feedbacks");
        // if backend returns an object with array inside:
        const data = Array.isArray(res.data) ? res.data : res.data.feedbacks;
        setFeedbacks(data || []);
      } catch (error) {
        console.error("Error fetching feedbacks:", error);
        setFeedbacks([]);
      } finally {
        setLoading(false);
      }
    };

    fetchFeedbacks();
  }, []);

  if (loading) return <p>Loading feedbacks...</p>;
  if (!feedbacks.length) return <p>No feedbacks found.</p>;

 return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">User Feedbacks</h1>
      <ul>
        {feedbacks.map((fb) => (
          <li key={fb._id} className="border p-3 rounded mb-3">
            <p><strong>Email:</strong> {fb.email}</p>
            <p><strong>Feedback:</strong> {fb.feedback}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminFeedbackPage;