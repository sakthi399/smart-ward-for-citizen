import React, { useState } from "react"; 
import { useNavigate, useParams } from "react-router-dom";
import api from "../utils/api";

const AdminLogin = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [wardNo, setWardNo] = useState(""); 
  const [adminPasskey, setAdminPasskey] = useState(""); // ✅ Admin passkey
  const navigate = useNavigate();
  const { role } = useParams();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      let res;

      if (role.toLowerCase() === "admin") {
        // 🔑 Admin login via passkey
        if (!adminPasskey) return alert("Enter admin passkey!");
        res = await api.post("/admin-login", { passkey: adminPasskey });
      } else {
        // 👤 Regular login for Councilor, Mayor, Commissioner
        const payload = { email, password };
        if (role.toLowerCase() === "councilor") payload.wardNo = Number(wardNo);
        res = await api.post("/login", payload);
      }

      // Save token & role
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("role", res.data.user.role);
      if (res.data.user.wardNo) localStorage.setItem("wardNo", res.data.user.wardNo);

      // Redirect based on role
      switch (res.data.user.role.toLowerCase()) {
        case "admin":
          navigate("/admin-dashboard");
          break;
        case "councilor":
          navigate(`/dashboard/councilor?ward=${wardNo}`);
          break;
        case "mayor":
          navigate("/dashboard/mayor");
          break;
        case "commissioner":
          navigate("/dashboard/commissioner");
          break;
        default:
          alert("Unauthorized role");
      }
    } catch (err) {
      alert(err.response?.data?.message || "Login failed");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 to-teal-500">
      <form onSubmit={handleLogin} className="bg-white p-8 rounded-lg shadow-md w-96 h-[400px]">
        <h2 className="text-2xl font-bold mb-6 text-center text-blue-600">
          {role.charAt(0).toUpperCase() + role.slice(1)} Login
        </h2>

        {role.toLowerCase() === "admin" ? (
          <input
            type="password"
            value={adminPasskey}
            onChange={(e) => setAdminPasskey(e.target.value)}
            className="w-full p-2 border rounded-lg mb-4"
            placeholder="Enter Admin Passkey"
            required
          />
        ) : (
          <>
            {role.toLowerCase() === "councilor" && (
              <select
                value={wardNo}
                onChange={(e) => setWardNo(e.target.value)}
                className="w-full p-2 border rounded-lg mb-4 hover:text-white hover:bg-blue-600"
                required
              >
                <option value="">Select Ward</option>
                <option value="1">Ward 1</option>
                <option value="2">Ward 2</option>
                <option value="3">Ward 3</option>
                <option value="4">Ward 4</option>
                <option value="5">Ward 5</option>
              </select>
            )}

            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2 border rounded-lg mb-4"
              placeholder="Email"
              required
            />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2 border rounded-lg mb-4"
              placeholder="Password"
              required
            />
          </>
        )}

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
        >
          Login
        </button>
      </form>
    </div>
  );
};

export default AdminLogin;
